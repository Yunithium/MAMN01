package com.example.migration;

import android.os.Vibrator;

public interface CustomActivity {
	public void changeActivity();
	public Vibrator getVibrator();
}
